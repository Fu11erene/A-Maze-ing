from sys import exit
from ..mazegen import MazeGenerator


def _print_operations() -> None:
    print("===A-maze-ing ===")
    print("1. Re-generate a new maze")
    print("2. Show / Hide the shortest path")
    print("3. Rotate the wall colours")
    print("4. Quit")


def visualize(maze_gen: MazeGenerator) -> None:
    """
    迷路の表示や表示の切り替えなどをするUI
    """
    maze_gen.generate_data()
    maze_gen.print_board()
    maze_gen.generate_output()
    if not maze_gen.is_42_renderable():
        print("WARN: Ommiting 42 pattern due to its size.")
    _print_operations()

    while True:
        try:
            choice = input("Choice? (1-4): ")
        except (KeyboardInterrupt, EOFError):
            return
        if choice == "1":
            maze_gen.generate_data()
            maze_gen.print_board()
            maze_gen.generate_output()
        elif choice == "2":
            maze_gen.toggle_path()
            maze_gen.print_board()
        elif choice == "3":
            maze_gen.rotate_wall_colour()
            maze_gen.print_board()
        elif choice == "4":
            exit(0)
        else:
            print("Invalid input. Try again.")
            continue
        _print_operations()
